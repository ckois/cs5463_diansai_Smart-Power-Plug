#ifndef __12864_H
#define __12864_H	
#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"

/******************************************************************
                        LCD12864�ӿڶ��弰��������
******************************************************************/
#define LCD_RS     GPIO_Pin_13   //PC13 
#define LCD_RW     GPIO_Pin_14   //PF14
#define LCD_EN     GPIO_Pin_15   //PF15
#define LCD_PSB    GPIO_Pin_0    //PB0
#define LCD_RST    GPIO_Pin_1    //PB1

#define  LCD12864     GPIOB
#define  LCD12864_1     GPIOC

#define  LCD_RS_H    GPIO_SetBits(LCD12864_1,LCD_RS)
#define  LCD_RS_L    GPIO_ResetBits(LCD12864_1,LCD_RS)

#define  SID_H    GPIO_SetBits(GPIOF,LCD_RW)
#define  SID_L    GPIO_ResetBits(GPIOF,LCD_RW)

#define  SCLK1_H    GPIO_SetBits(GPIOF,LCD_EN)
#define  SCLK1_L    GPIO_ResetBits(GPIOF,LCD_EN)

#define  LCD_PSB_H    GPIO_SetBits(LCD12864,LCD_PSB)
#define  LCD_PSB_L    GPIO_ResetBits(LCD12864,LCD_PSB)

#define  LCD_RST_H    GPIO_SetBits(LCD12864,LCD_RST)
#define  LCD_RST_L    GPIO_ResetBits(LCD12864,LCD_RST)

#define x1 0x80
#define x2 0x88
#define y  0x80

 
extern const unsigned char tab1[];
extern const unsigned char r[3];
void LCD12864_All_Init(void);
void LCD12864_GPIO_Init(void);
void LCM_init(void);
void Send_Byte(uint8_t bbyte);
void LCM_WriteCom(uint8_t Com);
void LCM_WriteDat(uint8_t data);
void LCD_Set_XY( uint8_t  X, uint8_t  Y );
void LCD_Write_String(uint8_t  X,uint8_t  Y,const uint8_t *s);
void LCD_Write_Number(uint8_t s);
//void Display_Img(uint8_t const *img);
void LCM_clr(void);
void LCM_WriteString(unsigned char *str);
void chn_disp (const uint8_t *chn);

#endif
