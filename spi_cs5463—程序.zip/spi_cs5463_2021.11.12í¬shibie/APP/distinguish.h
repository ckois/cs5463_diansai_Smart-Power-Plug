#ifndef _distinguish_H
#define _distinguish_H
#include "stm32f10x.h"












#endif
