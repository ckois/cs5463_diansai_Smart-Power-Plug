#include "sys.h"
#include "delay.h"
#include "usart.h"
#include <stdio.h>  
#include "spi.h"
#include "iic.h"
#include "cs5463.h"
#include "12864.h"
#include "usart3.h"
#include "key.h"
#include "timer.h"
#include "stdlib.h"
#include "font.h"
#include "oled.h"

extern int a0[3];
extern int b[3];
extern int c[3];
extern int d[3];
extern int e[3];
extern int f[3];
extern int g[3];

extern void Init_5463(void);
extern int dianya_avr;
extern int dianliu_avr;
extern float gonglv_avr;
extern float Qtrig;
//extern int wendu_avr;
extern char sumc1[200][50];
extern int lei;
extern float yinshu;

 int main(void)
 {
	 int count1;
	 char *stV[]={"Voltage(V):"};
	 char *stI[]={"Current(mA):"};
	 char *stP[]={"Active power(W):"};
	 char *stQ[]={"Reactive power(W):"};
	 char *stT[]={"Temperature('C):"};
	 char *stK[]={"Type:"};
	 char *stN[]={"None"};
	 char *stN1[]={"unidentifiable"};
	 char *stdata;
	 char *strline[]={"\r\n"};
		
	 int a0[3]={0,0,0};
	 int b[3]={0};
	 int c[3]={0};
	 int d[3]={0};
	 int e[3]={0};
	 int f[3]={0};
	 int g[3]={0};
		u8 key=0;	
	 
	 char a,temp = 0xf8;
	delay_init();	    //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(9600);	 
	usart3_init(9600);
//	 LCD12864_GPIO_Init();
	SPI2_Init();		   	//��ʼ��SPI
	SPI2_SetSpeed(SPI_BaudRatePrescaler_128);//����Ϊ18Mʱ��,����ģʽ 
           //��Դ����ʼ��
	CS5463_IO_Init();	 
	CS5463_Init(); 
  Oled_Init();
//	key_init();          //��ʼ���밴�����ӵ�Ӳ���ӿ�
	
	key_init();	   

	stdata=(char *)malloc(sizeof(char));
//	stdata= &strtext[0];

	printf("start to check current \r\n");  

while(1)
{
	
//		key=HL_Scan();	//�õ���ֵ
	key=KEY_Scan(1);
	   	if(key)
		{		
printf("start to check current \r\n"); 			
			switch(key)
			{				 
				
				case 1:	//ѧϰģʽ					
				{
			     
					  
            mode_xuexi(count1);	
            delay_ms(2000);
			   	count1++;
					if(count1==7)
						count1=0;
				
					 key=2;
				}
				     	break;
//				case 2:	
				default:
				{
				   // LED1=1;
					printf("start to check current \r\n"); 
				    main_CS5463();
				if(dianliu_avr>4000)
				{  	
			   	TIM3_Int_Init(9999,35999);
				}
			if(USART3_RX_STA&0x8000&&0)
		        {
		          if(USART3_RX_BUF[0]=='0')
			  {
			      
			      stdata=int2str(dianya_avr); 
		     	   Com3SendStr(*stV);
             Com3SendStr(stdata);
		  	   	Com3SendStr(*strline); 
				 
			     	 stdata=int2str(dianliu_avr);
		       	Com3SendStr(*stI);
			  	   Com3SendStr(stdata);
		    	 	Com3SendStr(*strline); 
				 
				    float_to_str(stdata,gonglv_avr);
				    Com3SendStr(*stP);
				   	 Com3SendStr(stdata);
						Com3SendStr(*strline); 
					
				  	 float_to_str(stdata,Qtrig);
				    Com3SendStr(*stQ);
				    Com3SendStr(stdata);
						Com3SendStr(*strline); 

//	           stdata=int2str(wendu_avr);
//	           Com3SendStr(*stT);
//	    			 Com3SendStr(stdata);
//						Com3SendStr(*strline); 
						
						Com3SendStr(*stK);
						if(yinshu>0.4&&gonglv_avr>0.8)
						Com3SendStr(sumc1[lei]);	
            else if(gonglv_avr<0.8)
            Com3SendStr(*stN);
            else
            Com3SendStr(*stN1);			
						Com3SendStr(*strline); 
						Com3SendStr(*strline); 
			 }
				
			 if(USART3_RX_BUF[0]=='1')
			
			 USART3_RX_STA=0;
		 }
					
				}
					break;
//				case KEY_PRES:	//ͬʱ����LED0,LED1��ת 
//				{  LED1=!LED1;
//					 delay_ms(2000);
//				   jidianqi=!jidianqi;
//					 break;
//			 }
		}
			
   delay_ms(1000);	//��ʱ	
	}
	
 }

}




//extern void Init_5463(void);



// int main(void)
// {	
//	  int count1;
//		delay_init();	    //��ʱ������ʼ��	  
//		uart_init(115200);
//	  LCD12864_All_Init();  // 12864��ʼ��	  
//		 LCM_clr();            //����
//		SPI2_Init();		   	//��ʼ��SPI
//		SPI2_SetSpeed(SPI_BaudRatePrescaler_128);//����Ϊ18Mʱ��,����ģʽ 
//		//��Դ����ʼ��
//		CS5463_IO_Init();	 
//		CS5463_Init();
//	  LCD_Write_String(1,0,"����A");
//	  LCD_Write_String(1,3,"��ѹ     V");
//		LCD_Write_String(2,0,"����          mA");
//	  LCD_Write_String(3,0,"����           W");
//	  LCD_Write_String(4,0,"��������       %");
//	printf("start to check current \r\n"); 
//	 
//	while(1)
//	{
		
//		main_CS5463(count1);
//		//����
//		printf("���� = %f \r\n",CS5463_Get_Value(0x16));
//		//��ѹ
//		printf("��ѹ = %f \r\n",CS5463_Get_Value(0x18));
//		//Ƶ��
//		printf("Ƶ�� = %f \r\n",CS5463_Get_Value(0x1A));
//		//��������
//		printf("�������� = %f \r\n",CS5463_Get_Value(0x32));
//		printf("\r\n");
//	}
// }



