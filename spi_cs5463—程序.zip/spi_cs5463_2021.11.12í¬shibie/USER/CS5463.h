#ifndef __CC5463_H
#define __CC5463_H	 
#include "sys.h"


		 			
void main_CS5463(void);
char CS5463_Init(void);
void CS5463_IO_Init(void);
char * int2str(int num);
void mode_xuexi(int count1);
	
#endif

